module AgendaPersonnel {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.base;
    requires java.sql;
    
    opens agenda.model to javafx.base, javafx.controls;
    opens agenda.view to javafx.fxml, javafx.controls;
    opens agendapersonnel to javafx.graphics;
    opens agenda.dao to javafx.base;
    opens agenda.util to javafx.base;
    
    exports agendapersonnel;
}