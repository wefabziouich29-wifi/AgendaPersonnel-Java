package agendapersonnel;

import agenda.util.ConnexionDB;
import agenda.util.RappelService;
import agenda.view.AgendaView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        AgendaView vue = new AgendaView();
        Scene scene = new Scene(vue.getRoot(), 950, 650);

        primaryStage.setTitle("Agenda Personnel");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(500);

        RappelService.demarrer();

        primaryStage.setOnCloseRequest(e -> {
            RappelService.arreter();
            ConnexionDB.fermer();
        });

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}