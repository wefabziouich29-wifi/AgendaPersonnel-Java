/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package agendapersonnel;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class AgendaPersonnel extends Application {

    @Override
    public void start(Stage fenetrePrincipale) {
        Label etiquette = new Label("Agenda Personnel fonctionne !");
        StackPane racine = new StackPane(etiquette);
        Scene scene = new Scene(racine, 400, 300);
        fenetrePrincipale.setTitle("Agenda Personnel");
        fenetrePrincipale.setScene(scene);
        fenetrePrincipale.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
