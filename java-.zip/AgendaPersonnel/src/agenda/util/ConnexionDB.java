package agenda.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnexionDB {

    private static final String URL      = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
    private static final String USER     = "system";
    private static final String PASSWORD = "55416538wefa";

    private static Connection connexion = null;

    public static Connection getConnexion() throws SQLException {
        if (connexion == null || connexion.isClosed()) {
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                connexion = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Connexion Oracle etablie.");
            } catch (ClassNotFoundException e) {
                throw new SQLException(
                    "Driver Oracle introuvable. Ajoutez ojdbc11.jar au classpath.", e);
            }
        }
        return connexion;
    }

    public static void fermer() {
        try {
            if (connexion != null && !connexion.isClosed()) {
                connexion.close();
                System.out.println("Connexion Oracle fermee.");
            }
        } catch (SQLException e) {
            System.err.println("Erreur fermeture : " + e.getMessage());
        }
    }
}