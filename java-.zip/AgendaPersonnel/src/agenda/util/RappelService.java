package agenda.util;

import agenda.dao.EvenementDAO;
import agenda.model.Evenement;
import javafx.application.Platform;
import javafx.scene.control.Alert;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class RappelService {

    private static final long INTERVALLE_MS = 30_000;
    private static Timer timer = null;

    public static void demarrer() {
        if (timer != null) return;
        timer = new Timer("RappelTimer", true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                verifierRappels();
            }
        }, 5_000, INTERVALLE_MS);
        System.out.println("Service de rappel demarre.");
    }

    public static void arreter() {
        if (timer != null) {
            timer.cancel();
            timer = null;
            System.out.println("Service de rappel arrete.");
        }
    }

    private static void verifierRappels() {
        EvenementDAO dao = new EvenementDAO();
        List<Evenement> aRappeler = dao.getEvenementsARappeler();
        for (Evenement evt : aRappeler) {
            dao.marquerRappelDeclenche(evt.getId());
            Platform.runLater(() -> afficherAlerte(evt));
        }
    }

    private static void afficherAlerte(Evenement evt) {
        Alert alerte = new Alert(Alert.AlertType.INFORMATION);
        alerte.setTitle("Rappel d'evenement");
        alerte.setHeaderText("Rappel : " + evt.getTitre());
        alerte.setContentText(
            "Date  : " + evt.getDate()  + "\n" +
            "Heure : " + evt.getHeure() + "\n" +
            "Type  : " + evt.getType()  + "\n\n" +
            (evt.getDescription() != null && !evt.getDescription().isEmpty()
                ? evt.getDescription() : "(pas de description)")
        );
        alerte.showAndWait();
    }
}