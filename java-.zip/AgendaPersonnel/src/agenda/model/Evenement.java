package agenda.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Evenement {

    private int id;
    private String titre;
    private LocalDate date;
    private LocalTime heure;
    private String description;
    private String type;
    private int rappelMinutes;
    private boolean rappelDeclenche;

    public Evenement() {}

    public Evenement(int id, String titre, LocalDate date, LocalTime heure,
                     String description, String type,
                     int rappelMinutes, boolean rappelDeclenche) {
        this.id               = id;
        this.titre            = titre;
        this.date             = date;
        this.heure            = heure;
        this.description      = description;
        this.type             = type;
        this.rappelMinutes    = rappelMinutes;
        this.rappelDeclenche  = rappelDeclenche;
    }

    public Evenement(String titre, LocalDate date, LocalTime heure,
                     String description, String type, int rappelMinutes) {
        this.titre            = titre;
        this.date             = date;
        this.heure            = heure;
        this.description      = description;
        this.type             = type;
        this.rappelMinutes    = rappelMinutes;
        this.rappelDeclenche  = false;
    }

    public int getId()                          { return id; }
    public void setId(int id)                   { this.id = id; }
    public String getTitre()                    { return titre; }
    public void setTitre(String titre)          { this.titre = titre; }
    public LocalDate getDate()                  { return date; }
    public void setDate(LocalDate date)         { this.date = date; }
    public LocalTime getHeure()                 { return heure; }
    public void setHeure(LocalTime heure)       { this.heure = heure; }
    public String getDescription()              { return description; }
    public void setDescription(String desc)     { this.description = desc; }
    public String getType()                     { return type; }
    public void setType(String type)            { this.type = type; }
    public int getRappelMinutes()               { return rappelMinutes; }
    public void setRappelMinutes(int min)       { this.rappelMinutes = min; }
    public boolean isRappelDeclenche()          { return rappelDeclenche; }
    public void setRappelDeclenche(boolean val) { this.rappelDeclenche = val; }

    @Override
    public String toString() {
        return titre + " - " + date + " a " + heure + " [" + type + "]";
    }
}