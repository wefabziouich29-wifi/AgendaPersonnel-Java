package agenda.dao;

import agenda.util.ConnexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TypeDAO {

    public List<String> getTousLesTypes() {
        List<String> liste = new ArrayList<>();
        String sql = "SELECT NOM FROM TYPES_EVT ORDER BY NOM";
        try (Statement st = ConnexionDB.getConnexion().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) liste.add(rs.getString("NOM"));
        } catch (SQLException ex) {
            System.err.println("Erreur getTousLesTypes : " + ex.getMessage());
        }
        return liste;
    }

    public boolean ajouterType(String nom) {
        String sql = "INSERT INTO TYPES_EVT (NOM) VALUES (?)";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setString(1, nom);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean typeExiste(String nom) {
        String sql = "SELECT COUNT(*) FROM TYPES_EVT WHERE UPPER(NOM) = UPPER(?)";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setString(1, nom);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException ex) {
            System.err.println("Erreur typeExiste : " + ex.getMessage());
        }
        return false;
    }
}