package agenda.dao;

import agenda.model.Evenement;
import agenda.util.ConnexionDB;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class EvenementDAO {

    // ── Vérification doublon ───────────────────────────────────────────────────
    // Retourne null si pas de doublon, sinon un message décrivant l'événement existant
    // excludeId = -1 pour un ajout, sinon l'id de l'événement en cours de modification
   public String verifierDoublon(String titre, LocalDate date, LocalTime heure, int excludeId) {
    String sql = "SELECT TITRE, DATE_EVT, HEURE_EVT, DESCRIPTION FROM EVENEMENTS " +
                 "WHERE DATE_EVT = ? AND HEURE_EVT = ?";
    if (excludeId >= 0) sql += " AND ID != " + excludeId;
    try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
        ps.setDate  (1, Date.valueOf(date));
        ps.setString(2, heure.toString());
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return "\"" + rs.getString("TITRE") + "\"  |  "
                     + rs.getDate("DATE_EVT").toLocalDate() + "  à  "
                     + rs.getString("HEURE_EVT") + "\n"
                     + (rs.getString("DESCRIPTION") != null ? rs.getString("DESCRIPTION") : "");
            }
        }
    } catch (SQLException ex) {
        System.err.println("Erreur verifierDoublon : " + ex.getMessage());
    }
    return null;
}

    public boolean ajouter(Evenement e) {
        String sql = "INSERT INTO EVENEMENTS "
                   + "(TITRE, DATE_EVT, HEURE_EVT, DESCRIPTION, TYPE_EVT, "
                   + " RAPPEL_MINUTES, RAPPEL_DECLENCHE) "
                   + "VALUES (?, ?, ?, ?, ?, ?, 0)";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setString(1, e.getTitre());
            ps.setDate  (2, Date.valueOf(e.getDate()));
            ps.setString(3, e.getHeure().toString());
            ps.setString(4, e.getDescription());
            ps.setString(5, e.getType());
            ps.setInt   (6, e.getRappelMinutes());
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Erreur ajouter : " + ex.getMessage());
            return false;
        }
    }

    public List<Evenement> getTous() {
        List<Evenement> liste = new ArrayList<>();
        String sql = "SELECT * FROM EVENEMENTS ORDER BY DATE_EVT, HEURE_EVT";
        try (Statement st = ConnexionDB.getConnexion().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) liste.add(construire(rs));
        } catch (SQLException ex) {
            System.err.println("Erreur getTous : " + ex.getMessage());
        }
        return liste;
    }

    public List<Evenement> getParDate(LocalDate date) {
        List<Evenement> liste = new ArrayList<>();
        String sql = "SELECT * FROM EVENEMENTS WHERE DATE_EVT = ? ORDER BY HEURE_EVT";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) liste.add(construire(rs));
            }
        } catch (SQLException ex) {
            System.err.println("Erreur getParDate : " + ex.getMessage());
        }
        return liste;
    }

    public List<Evenement> rechercherParTitre(String motCle) {
        List<Evenement> liste = new ArrayList<>();
        String sql = "SELECT * FROM EVENEMENTS WHERE UPPER(TITRE) LIKE UPPER(?) ORDER BY DATE_EVT";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setString(1, "%" + motCle + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) liste.add(construire(rs));
            }
        } catch (SQLException ex) {
            System.err.println("Erreur rechercherParTitre : " + ex.getMessage());
        }
        return liste;
    }

    public List<Evenement> getParType(String type) {
        List<Evenement> liste = new ArrayList<>();
        String sql = "SELECT * FROM EVENEMENTS WHERE TYPE_EVT = ? ORDER BY DATE_EVT";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setString(1, type);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) liste.add(construire(rs));
            }
        } catch (SQLException ex) {
            System.err.println("Erreur getParType : " + ex.getMessage());
        }
        return liste;
    }

    public List<Evenement> getEvenementsARappeler() {
        List<Evenement> liste = new ArrayList<>();
        String sql =
            "SELECT * FROM EVENEMENTS " +
            "WHERE RAPPEL_MINUTES > 0 AND RAPPEL_DECLENCHE = 0 " +
            "AND (TO_DATE(TO_CHAR(DATE_EVT,'DD/MM/YYYY') || ' ' || HEURE_EVT, " +
            "            'DD/MM/YYYY HH24:MI') - RAPPEL_MINUTES/1440) <= SYSDATE";
        try (Statement st = ConnexionDB.getConnexion().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) liste.add(construire(rs));
        } catch (SQLException ex) {
            System.err.println("Erreur getEvenementsARappeler : " + ex.getMessage());
        }
        return liste;
    }

    public boolean modifier(Evenement e) {
        String sql = "UPDATE EVENEMENTS SET "
                   + "TITRE=?, DATE_EVT=?, HEURE_EVT=?, DESCRIPTION=?, "
                   + "TYPE_EVT=?, RAPPEL_MINUTES=? WHERE ID=?";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setString(1, e.getTitre());
            ps.setDate  (2, Date.valueOf(e.getDate()));
            ps.setString(3, e.getHeure().toString());
            ps.setString(4, e.getDescription());
            ps.setString(5, e.getType());
            ps.setInt   (6, e.getRappelMinutes());
            ps.setInt   (7, e.getId());
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException ex) {
            System.err.println("Erreur modifier : " + ex.getMessage());
            return false;
        }
    }

    public void marquerRappelDeclenche(int id) {
        String sql = "UPDATE EVENEMENTS SET RAPPEL_DECLENCHE=1 WHERE ID=?";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Erreur marquerRappelDeclenche : " + ex.getMessage());
        }
    }

    public boolean supprimer(int id) {
        String sql = "DELETE FROM EVENEMENTS WHERE ID=?";
        try (PreparedStatement ps = ConnexionDB.getConnexion().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Erreur supprimer : " + ex.getMessage());
            return false;
        }
    }

    private Evenement construire(ResultSet rs) throws SQLException {
        int       id        = rs.getInt   ("ID");
        String    titre     = rs.getString("TITRE");
        LocalDate date      = rs.getDate  ("DATE_EVT").toLocalDate();
        LocalTime heure     = LocalTime.parse(rs.getString("HEURE_EVT"));
        String    desc      = rs.getString("DESCRIPTION");
        String    type      = rs.getString("TYPE_EVT");
        int       rappelMin = rs.getInt   ("RAPPEL_MINUTES");
        boolean   declenche = rs.getInt   ("RAPPEL_DECLENCHE") == 1;
        return new Evenement(id, titre, date, heure, desc, type, rappelMin, declenche);
    }
}