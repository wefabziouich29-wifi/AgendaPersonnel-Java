package agenda.view;

import agenda.dao.EvenementDAO;
import agenda.dao.TypeDAO;
import agenda.model.Evenement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ListeEvenementsView {

    private final LocalDate dateFiltree;
    private final EvenementDAO dao;
    private final TypeDAO typeDAO = new TypeDAO();
    private final Runnable onFermeture;

    private ObservableList<Evenement> evenements = FXCollections.observableArrayList();
    private TableView<Evenement> tableau;
    private TextField champRecherche;
    private Label labelStatut;
    private Stage stage;
    private ComboBox<String> comboType;

    public ListeEvenementsView(LocalDate dateFiltree, EvenementDAO dao, Runnable onFermeture) {
        this.dateFiltree = dateFiltree;
        this.dao         = dao;
        this.onFermeture = onFermeture;
    }

    public void afficher() {
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Evenements");
        stage.setMinWidth(820);
        stage.setMinHeight(520);

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fdf0f5;");
        root.setTop(creerBandeauHaut());
        root.setCenter(creerContenu());
        root.setBottom(creerBarreStatut());

        Scene scene = new Scene(root, 900, 580);
        stage.setScene(scene);

        charger();

        stage.setOnHidden(e -> { if (onFermeture != null) onFermeture.run(); });
        stage.showAndWait();
    }

    private Parent creerBandeauHaut() {
        String titre = dateFiltree != null
            ? "Evenements du " + dateFiltree
            : "Tous les evenements";
        Label lbl = new Label(titre);
        lbl.setFont(Font.font("Georgia", FontWeight.BOLD, 18));
        lbl.setTextFill(Color.WHITE);
        HBox hb = new HBox(lbl);
        hb.setAlignment(Pos.CENTER_LEFT);
        hb.setPadding(new Insets(12, 20, 12, 20));
        hb.setStyle("-fx-background-color: linear-gradient(to right, #e91e8c, #f48fb1);");
        return hb;
    }

    private Parent creerContenu() {
        VBox vb = new VBox(12);
        vb.setPadding(new Insets(16));

        // ── Barre de recherche ──────────────────────────────────────────────
        HBox barre = new HBox(10);
        barre.setAlignment(Pos.CENTER_LEFT);

        Label lbl = new Label("Rechercher :");
        lbl.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
        lbl.setTextFill(Color.web("#880e4f"));

        champRecherche = new TextField();
        champRecherche.setPromptText("Titre de l'evenement...");
        champRecherche.setStyle(
            "-fx-background-radius: 14; -fx-border-radius: 14;" +
            "-fx-border-color: #f48fb1; -fx-padding: 6 10;"
        );
        HBox.setHgrow(champRecherche, Priority.ALWAYS);

        champRecherche.textProperty().addListener((obs, old, val) -> {
            if (val.trim().isEmpty()) charger();
        });

        Button btnChercher = creerBouton("Chercher", "#e91e8c");
        btnChercher.setOnAction(e -> rechercherParTitre());
        champRecherche.setOnAction(e -> rechercherParTitre());

        // ── Filtre par type chargé depuis la base ───────────────────────────
        comboType = new ComboBox<>();
        rafraichirComboTypes();
        comboType.setStyle(
            "-fx-background-color: #f48fb1; -fx-background-radius: 14;" +
            "-fx-border-radius: 14; -fx-border-color: #e91e8c;" +
            "-fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand;"
        );
        comboType.setOnAction(e -> filtrerParType());

        barre.getChildren().addAll(lbl, champRecherche, btnChercher, comboType);

        // ── Boutons actions ─────────────────────────────────────────────────
        HBox actions = new HBox(10);
        actions.setAlignment(Pos.CENTER_RIGHT);

        Button btnAjouter   = creerBouton("Ajouter",   "#f06292");
        Button btnModifier  = creerBouton("Modifier",  "#ba68c8");
        Button btnSupprimer = creerBouton("Supprimer", "#e57373");

        btnAjouter  .setOnAction(e -> ouvrirFormulaireAjout());
        btnModifier .setOnAction(e -> ouvrirFormulaireModification());
        btnSupprimer.setOnAction(e -> supprimerEvenement());

        actions.getChildren().addAll(btnAjouter, btnModifier, btnSupprimer);

        // ── Tableau ─────────────────────────────────────────────────────────
        creerTableau();
        VBox.setVgrow(tableau, Priority.ALWAYS);

        vb.getChildren().addAll(barre, actions, tableau);
        return vb;
    }

    private void rafraichirComboTypes() {
        List<String> types = new ArrayList<>();
        types.add("Tous les types");
        types.addAll(typeDAO.getTousLesTypes());
        comboType.getItems().setAll(types);
        comboType.setValue("Tous les types");
    }

    private void filtrerParType() {
        String type = comboType.getValue();
        if (type == null || type.equals("Tous les types")) {
            charger();
        } else {
            List<Evenement> liste = dao.getParType(type);
            evenements.setAll(liste);
            labelStatut.setText("Type \"" + type + "\" -> " + liste.size() + " resultat(s).");
        }
    }

    @SuppressWarnings("unchecked")
    private void creerTableau() {
        tableau = new TableView<>();
        tableau.setItems(evenements);
        tableau.setPlaceholder(new Label("Aucun evenement trouve."));
        tableau.setStyle("-fx-background-color: white; -fx-border-color: #f8bbd0;");

        TableColumn<Evenement, String>    colTitre  = new TableColumn<>("Titre");
        TableColumn<Evenement, LocalDate> colDate   = new TableColumn<>("Date");
        TableColumn<Evenement, String>    colHeure  = new TableColumn<>("Heure");
        TableColumn<Evenement, String>    colType   = new TableColumn<>("Type");
        TableColumn<Evenement, String>    colDesc   = new TableColumn<>("Description");
        TableColumn<Evenement, Integer>   colRappel = new TableColumn<>("Rappel (min)");

        colTitre .setCellValueFactory(new PropertyValueFactory<>("titre"));
        colDate  .setCellValueFactory(new PropertyValueFactory<>("date"));
        colHeure .setCellValueFactory(new PropertyValueFactory<>("heure"));
        colType  .setCellValueFactory(new PropertyValueFactory<>("type"));
        colDesc  .setCellValueFactory(new PropertyValueFactory<>("description"));
        colRappel.setCellValueFactory(new PropertyValueFactory<>("rappelMinutes"));

        colTitre .setPrefWidth(200);
        colDate  .setPrefWidth(100);
        colHeure .setPrefWidth(80);
        colType  .setPrefWidth(110);
        colDesc  .setPrefWidth(200);
        colRappel.setPrefWidth(90);

        tableau.getColumns().addAll(colTitre, colDate, colHeure, colType, colDesc, colRappel);

        tableau.setRowFactory(tv -> {
            TableRow<Evenement> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty())
                    ouvrirFormulaireModification();
            });
            return row;
        });
    }

    private Parent creerBarreStatut() {
        labelStatut = new Label("Pret.");
        labelStatut.setPadding(new Insets(6, 12, 6, 12));
        labelStatut.setTextFill(Color.web("#880e4f"));
        labelStatut.setStyle(
            "-fx-background-color: #fce4ec; -fx-border-color: #f8bbd0;" +
            "-fx-border-width: 1 0 0 0;"
        );
        return labelStatut;
    }

    // ── Chargement ─────────────────────────────────────────────────────────────
    private void charger() {
        List<Evenement> liste = (dateFiltree != null)
            ? dao.getParDate(dateFiltree)
            : dao.getTous();
        evenements.setAll(liste);
        labelStatut.setText(liste.size() + " evenement(s) affiche(s).");
    }

    private void rechercherParTitre() {
        String mc = champRecherche.getText().trim();
        if (mc.isEmpty()) { charger(); return; }
        List<Evenement> liste = dao.rechercherParTitre(mc);
        evenements.setAll(liste);
        labelStatut.setText("Recherche \"" + mc + "\" -> " + liste.size() + " resultat(s).");
    }

    // ── Actions CRUD ───────────────────────────────────────────────────────────
    private void ouvrirFormulaireAjout() {
        FormulaireEvenement form = new FormulaireEvenement(null);
        Optional<Evenement> result = form.afficher();
        result.ifPresent(e -> {
            String erreur = dao.verifierDoublon(e.getTitre(), e.getDate(), e.getHeure(), -1);
            if (erreur != null) {
                afficherErreur("Un evenement existe deja a cette date et heure :\n" + erreur);
                return;
            }
            if (dao.ajouter(e)) {
                charger();
                rafraichirComboTypes();
                labelStatut.setText("Evenement ajoute.");
            } else {
                afficherErreur("Impossible d'ajouter l'evenement.");
            }
        });
    }

    private void ouvrirFormulaireModification() {
        Evenement sel = tableau.getSelectionModel().getSelectedItem();
        if (sel == null) { afficherInfo("Selectionnez un evenement a modifier."); return; }

        FormulaireEvenement form = new FormulaireEvenement(sel);
        Optional<Evenement> result = form.afficher();
        result.ifPresent(e -> {
            e.setId(sel.getId());
            String erreur = dao.verifierDoublon(e.getTitre(), e.getDate(), e.getHeure(), sel.getId());
            if (erreur != null) {
                afficherErreur("Un evenement existe deja a cette date et heure :\n" + erreur);
                return;
            }
            if (dao.modifier(e)) {
                charger();
                rafraichirComboTypes();
                labelStatut.setText("Evenement modifie.");
            } else {
                afficherErreur("Impossible de modifier l'evenement.");
            }
        });
    }

    private void supprimerEvenement() {
        Evenement sel = tableau.getSelectionModel().getSelectedItem();
        if (sel == null) { afficherInfo("Selectionnez un evenement a supprimer."); return; }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Supprimer : " + sel.getTitre() + " ?");
        confirm.setContentText("Cette action est irreversible.");
        Optional<ButtonType> rep = confirm.showAndWait();
        if (rep.isPresent() && rep.get() == ButtonType.OK) {
            if (dao.supprimer(sel.getId())) {
                charger();
                labelStatut.setText("Evenement supprime.");
            } else {
                afficherErreur("Impossible de supprimer l'evenement.");
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    private Button creerBouton(String texte, String couleurFond) {
        Button btn = new Button(texte);
        btn.setStyle(
            "-fx-background-color: " + couleurFond + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold; -fx-cursor: hand;" +
            "-fx-background-radius: 16; -fx-padding: 6 14;"
        );
        return btn;
    }

    private void afficherErreur(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Erreur");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    private void afficherInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}