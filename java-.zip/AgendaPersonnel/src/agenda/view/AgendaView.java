package agenda.view;

import agenda.dao.EvenementDAO;
import agenda.model.Evenement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;

public class AgendaView {

    private final EvenementDAO dao = new EvenementDAO();
    private BorderPane root;
    private YearMonth moisAffiche = YearMonth.now();
    private GridPane grilleCalendrier;
    private Label labelMois;

    public AgendaView() {
        construireInterface();
    }

    public Parent getRoot() {
        return root;
    }

    private void construireInterface() {
        root = new BorderPane();
        root.setStyle("-fx-background-color: #fdf0f5;");
        root.setTop(creerBandeauHaut());
        root.setCenter(creerPanneauCalendrier());
    }

    // ─── Bandeau haut ─────────────────────────────────────────────────────────
    private Parent creerBandeauHaut() {
        Label titre = new Label("Mon Agenda");
        titre.setFont(Font.font("Georgia", FontWeight.BOLD, 26));
        titre.setTextFill(Color.WHITE);

        HBox bandeau = new HBox(titre);
        bandeau.setAlignment(Pos.CENTER);
        bandeau.setPadding(new Insets(18, 20, 18, 20));
        bandeau.setStyle(
            "-fx-background-color: linear-gradient(to right, #e91e8c, #f48fb1);"
        );
        return bandeau;
    }

    // ─── Panneau calendrier ───────────────────────────────────────────────────
    private Parent creerPanneauCalendrier() {
        VBox panneau = new VBox(16);
        panneau.setPadding(new Insets(24));
        panneau.setAlignment(Pos.TOP_CENTER);

        // Navigation mois
        Button btnPrev = creerBoutonNav("◀");
        Button btnNext = creerBoutonNav("▶");
        labelMois = new Label();
        labelMois.setFont(Font.font("Georgia", FontWeight.BOLD, 18));
        labelMois.setTextFill(Color.web("#c2185b"));

        btnPrev.setOnAction(e -> { moisAffiche = moisAffiche.minusMonths(1); rafraichirCalendrier(); });
        btnNext.setOnAction(e -> { moisAffiche = moisAffiche.plusMonths(1);  rafraichirCalendrier(); });

        HBox navBar = new HBox(16, btnPrev, labelMois, btnNext);
        navBar.setAlignment(Pos.CENTER);

        // Grille
        grilleCalendrier = new GridPane();
        grilleCalendrier.setHgap(8);
        grilleCalendrier.setVgap(8);
        grilleCalendrier.setAlignment(Pos.CENTER);

        // En-têtes jours
        String[] jours = {"Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"};
        for (int i = 0; i < 7; i++) {
            Label lbl = new Label(jours[i]);
            lbl.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
            lbl.setTextFill(Color.web("#ad1457"));
            lbl.setPrefWidth(60);
            lbl.setAlignment(Pos.CENTER);
            grilleCalendrier.add(lbl, i, 0);
        }

        rafraichirCalendrier();

        // Bouton Événements
        Button btnEvt = new Button("📋  Événements");
        btnEvt.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        btnEvt.setPrefWidth(220);
        btnEvt.setPrefHeight(44);
        btnEvt.setStyle(
            "-fx-background-color: linear-gradient(to right, #e91e8c, #f48fb1);" +
            "-fx-text-fill: white; -fx-background-radius: 22; -fx-cursor: hand;"
        );
        btnEvt.setOnAction(e -> ouvrirListeEvenements(null));

        panneau.getChildren().addAll(navBar, grilleCalendrier, btnEvt);
        return panneau;
    }

    private void rafraichirCalendrier() {
        // Supprimer les cellules (garder ligne 0 = en-têtes)
        grilleCalendrier.getChildren().removeIf(n -> GridPane.getRowIndex(n) != null && GridPane.getRowIndex(n) > 0);

        String[] moisNoms = {"Janvier","Février","Mars","Avril","Mai","Juin",
                             "Juillet","Août","Septembre","Octobre","Novembre","Décembre"};
        labelMois.setText(moisNoms[moisAffiche.getMonthValue() - 1] + "  " + moisAffiche.getYear());

        LocalDate premier = moisAffiche.atDay(1);
        // lundi=1 … dimanche=7
        int debutCol = premier.getDayOfWeek().getValue() - 1;
        int nbJours  = moisAffiche.lengthOfMonth();
        LocalDate aujd = LocalDate.now();

        int col = debutCol;
        int lig = 1;
        for (int j = 1; j <= nbJours; j++) {
            LocalDate date = moisAffiche.atDay(j);
            List<Evenement> evts = dao.getParDate(date);

            VBox cellule = new VBox(2);
            cellule.setAlignment(Pos.TOP_CENTER);
            cellule.setPrefSize(60, 56);
            cellule.setPadding(new Insets(4));

            boolean estAujourd = date.equals(aujd);
            boolean aDesEvts   = !evts.isEmpty();

            String bg;
            if (estAujourd)      bg = "#e91e8c";
            else if (aDesEvts)   bg = "#f8bbd0";
            else                 bg = "#fff0f5";

            String textColor = estAujourd ? "white" : "#880e4f";

            cellule.setStyle(
                "-fx-background-color: " + bg + ";" +
                "-fx-background-radius: 10;" +
                "-fx-cursor: hand;"
            );

            Label lblJ = new Label(String.valueOf(j));
            lblJ.setFont(Font.font("Verdana", estAujourd ? FontWeight.BOLD : FontWeight.NORMAL, 13));
            lblJ.setTextFill(Color.web(textColor));

            cellule.getChildren().add(lblJ);

            if (aDesEvts) {
                Label dot = new Label("● " + evts.size());
                dot.setFont(Font.font("Verdana", 9));
                dot.setTextFill(Color.web(estAujourd ? "white" : "#c2185b"));
                cellule.getChildren().add(dot);
            }

            // Survol
            cellule.setOnMouseEntered(e -> cellule.setStyle(
                "-fx-background-color: #f48fb1; -fx-background-radius: 10; -fx-cursor: hand;"
            ));
            cellule.setOnMouseExited(e -> cellule.setStyle(
                "-fx-background-color: " + bg + "; -fx-background-radius: 10; -fx-cursor: hand;"
            ));

            final LocalDate dateFinal = date;
            cellule.setOnMouseClicked(e -> ouvrirListeEvenements(dateFinal));

            grilleCalendrier.add(cellule, col, lig);

            col++;
            if (col == 7) { col = 0; lig++; }
        }
    }

    private Button creerBoutonNav(String texte) {
        Button btn = new Button(texte);
        btn.setStyle(
            "-fx-background-color: #f8bbd0; -fx-text-fill: #880e4f;" +
            "-fx-font-weight: bold; -fx-background-radius: 16; -fx-cursor: hand; -fx-font-size: 14;"
        );
        return btn;
    }

    // ─── Ouvrir liste événements ───────────────────────────────────────────────
    private void ouvrirListeEvenements(LocalDate dateFiltree) {
        ListeEvenementsView liste = new ListeEvenementsView(dateFiltree, dao, () -> rafraichirCalendrier());
        liste.afficher();
    }
}