package agenda.view;

import agenda.dao.TypeDAO;
import agenda.model.Evenement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

public class FormulaireEvenement {

    private final Evenement evenementExistant;
    private final TypeDAO typeDAO = new TypeDAO();

    public FormulaireEvenement(Evenement e) {
        this.evenementExistant = e;
    }

    public Optional<Evenement> afficher() {
        Dialog<Evenement> dialog = new Dialog<>();
        dialog.setTitle(evenementExistant == null ? "Ajouter un evenement" : "Modifier un evenement");
        dialog.initModality(Modality.APPLICATION_MODAL);

        // ── Champs ──────────────────────────────────────────────────────────
        TextField champTitre = new TextField();
        champTitre.setPromptText("Titre *");
        champTitre.setStyle(styleChamp());

        DatePicker champDate = new DatePicker();
        champDate.setPromptText("Date *");
        champDate.setStyle(styleChamp());

        TextField champHeure = new TextField();
        champHeure.setPromptText("HH:MM  (ex: 14:30) *");
        champHeure.setStyle(styleChamp());

        // Description initialisée avec "" pour éviter null
        TextArea champDesc = new TextArea("");
        champDesc.setPromptText("Description (optionnelle)");
        champDesc.setPrefRowCount(3);
        champDesc.setWrapText(true);
        champDesc.setStyle(styleChamp());

        // Charger les types depuis la base
        List<String> typesDB = typeDAO.getTousLesTypes();
        ObservableList<String> typesListe = FXCollections.observableArrayList(typesDB);

        ComboBox<String> comboType = new ComboBox<>(typesListe);
        comboType.setEditable(true);
        comboType.setValue(typesListe.isEmpty() ? "Rendez-vous" : typesListe.get(0));
        comboType.setMaxWidth(Double.MAX_VALUE);
        comboType.setStyle(styleChamp());
        comboType.setPromptText("Type *");

        Spinner<Integer> spinnerRappel = new Spinner<>(0, 1440, 0, 5);
        spinnerRappel.setEditable(true);
        spinnerRappel.setMaxWidth(Double.MAX_VALUE);

        // Pré-remplissage si modification
        if (evenementExistant != null) {
            champTitre.setText(evenementExistant.getTitre() != null ? evenementExistant.getTitre() : "");
            champDate .setValue(evenementExistant.getDate());
            champHeure.setText(evenementExistant.getHeure() != null ? evenementExistant.getHeure().toString() : "");
            champDesc .setText(evenementExistant.getDescription() != null ? evenementExistant.getDescription() : "");
            String type = evenementExistant.getType();
            if (type != null && !typesListe.contains(type)) typesListe.add(type);
            comboType.setValue(type != null ? type : "Rendez-vous");
            spinnerRappel.getValueFactory().setValue(evenementExistant.getRappelMinutes());
        }

        // ── Mise en page ─────────────────────────────────────────────────────
        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));
        grid.setStyle("-fx-background-color: #fdf0f5;");

        grid.add(labelForm("Titre *"),       0, 0); grid.add(champTitre,    1, 0);
        grid.add(labelForm("Date *"),        0, 1); grid.add(champDate,     1, 1);
        grid.add(labelForm("Heure *"),       0, 2); grid.add(champHeure,    1, 2);
        grid.add(labelForm("Type *"),        0, 3); grid.add(comboType,     1, 3);
        grid.add(labelForm("Rappel (min)"),  0, 4); grid.add(spinnerRappel, 1, 4);
        grid.add(labelForm("Description"),   0, 5); grid.add(champDesc,     1, 5);

        ColumnConstraints col0 = new ColumnConstraints(110);
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(col0, col1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(460);

        ButtonType btnValider = new ButtonType(
            evenementExistant == null ? "Ajouter" : "Modifier",
            ButtonBar.ButtonData.OK_DONE
        );
        dialog.getDialogPane().getButtonTypes().addAll(btnValider, ButtonType.CANCEL);

        Button okBtn = (Button) dialog.getDialogPane().lookupButton(btnValider);
        okBtn.setStyle(
            "-fx-background-color: #e91e8c; -fx-text-fill: white;" +
            "-fx-font-weight: bold; -fx-background-radius: 16;"
        );

        // ── Résultat ─────────────────────────────────────────────────────────
        dialog.setResultConverter(bt -> {
            if (bt != btnValider) return null;

            String titre    = champTitre.getText() != null ? champTitre.getText().trim() : "";
            LocalDate date  = champDate.getValue();
            String heureStr = champHeure.getText() != null ? champHeure.getText().trim() : "";
            String type     = comboType.getValue();
            if (type == null || type.isBlank()) type = "Autre";
            type = type.trim();

            // Description : protection null
            String desc = champDesc.getText() != null ? champDesc.getText().trim() : "";

            if (titre.isEmpty() || date == null || heureStr.isEmpty()) {
                afficherErreur("Les champs Titre, Date et Heure sont obligatoires.");
                return null;
            }

            LocalTime heure;
            try {
                heure = LocalTime.parse(heureStr);
            } catch (DateTimeParseException ex) {
                afficherErreur("Format heure invalide. Utilisez HH:MM (ex: 14:30).");
                return null;
            }

            // Sauvegarder le type en base s'il est nouveau
            if (!typeDAO.typeExiste(type)) {
                typeDAO.ajouterType(type);
            }

            int rappel = spinnerRappel.getValue();

            return new Evenement(titre, date, heure, desc, type, rappel);
        });

        return dialog.showAndWait();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private Label labelForm(String texte) {
        Label lbl = new Label(texte);
        lbl.setFont(Font.font("Verdana", FontWeight.BOLD, 11));
        lbl.setTextFill(Color.web("#880e4f"));
        lbl.setAlignment(Pos.CENTER_RIGHT);
        lbl.setMaxWidth(Double.MAX_VALUE);
        return lbl;
    }

    private String styleChamp() {
        return "-fx-background-radius: 8; -fx-border-radius: 8;" +
               "-fx-border-color: #f48fb1; -fx-padding: 5 8;";
    }

    private void afficherErreur(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Erreur de saisie");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
} 